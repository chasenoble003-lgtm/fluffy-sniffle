"use strict";

function getCanvasContext(){
    let canvas = document.getElementById("gameWindow");
    let ctx = canvas.getContext("2d");
    canvas.height = window.innerHeight;
    canvas.width = window.innerWidth;
    return [canvas,ctx];
}

function handleKeyDown(e,keysPressed){
    if(keysPressed[e.key] != undefined){
        keysPressed[e.key] = true;
    }
    return keysPressed;
}

function handleKeyUp(e,keysPressed){
    if(keysPressed[e.key] != undefined){
        keysPressed[e.key] = false;
    }
    return keysPressed;
}

function collidesX(object1,object2){
    if(object1.x + object1.width > object2.x && object1.x < object2.x + object2.width){
        return true;
    }
    else{
        return false;
    }
}

function collidesY(object1,object2){
    if(object1.y + object1.height > object2.y && object1.y < object2.y + object2.height){
        return true;
    }
    else{
        return false;
    }
}

function checkCollision(object,player){
    var vx = player.vx;
    var vy = player.vy;
    if(object.vx != 0){
        if(collidesY(object,player) && collidesX({x:object.x + vx,y:object.y,width:object.width,height:object.height},player)){
            if(Math.sign(vx) == -1){
                player.x = object.x - player.width;
            }
            else{
                player.x = object.x + object.width;
            }
            vx = 0;
        }
    }
    if(object.vy != 0){
        if(collidesX(object,player) && collidesY({x:object.x,y:object.y + vy,width:object.width,height:object.height},player)){
            if(Math.sign(vy) == -1){
                player.y = object.y - player.height;
            }
            else{
                player.y = object.y + object.height;
            }
            vy = 0;
        }
    }
    return [vx,vy];
}

class GameObject{
    constructor(x,y,width,height){
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.image = null;
        this.frame = {count:0,x:0,y:0,row:0};
        this.rotation = 1;
        this.angle = 0;
    }

    update(game){
        
    }

    draw(ctx){
        if(this.image != null){
            ctx.save();
            ctx.translate(this.x + this.width / 2, this.y + this.height / 2);
            ctx.rotate(this.angle * Math.PI / 180);
            ctx.scale(this.rotation, 1);
            ctx.drawImage(this.image,this.frame.x,this.frame.y,this.spriteWidth,this.spriteHeight,-this.width/2,-this.height/2,this.width,this.height);            ctx.restore();
        } 
        else{
            ctx.fillRect(this.x, this.y, this.width, this.height);
        }
    }

    animate(){
        if(this.vx != 0 || this.vy != 0){
                if(this.frame.count >= 12){
                    this.frame.count = 0;
                }
                if(this.frame.count != 0 && this.frame.count % (this.image.width / this.spriteWidth) == 0 && this.frame.row < 3){
                    this.frame.row++;
                }
                else if(this.frame.count % (this.image.width / this.spriteWidth) == 0){
                    this.frame.row = 0;
                }
                this.frame.x = this.frame.count % (this.image.width / this.spriteWidth) * this.spriteWidth;
                this.frame.y = this.frame.row * this.spriteHeight;
                this.frame.count++;
        }
        else{
            this.frame.count = 0;
            this.frame.x = 0;
            this.frame.y = 0;
        }
    }
}

class VisibleObject extends GameObject{
    constructor(x,y,width,height){
        super(x,y,width,height);
    }

    update(game){
        this.x += game.player.vx;
        this.y += game.player.vy
    }
}

class Player extends GameObject{
    constructor(x,y,width,height){
        super(x,y,width,height);
        this.image = document.getElementById("knight_walking");
        this.spriteWidth = 32;
        this.spriteHeight = 32;
        this.speed = 5;
        this.velocity = this.speed;
        this.vx = 0;
        this.vy = 0;
        this.sword = new Sword(this.x,this.y,50,10,this);
        this.toUpdate = [this,this.sword];
        this.toDraw = [this.sword,this];
    }

    start(){
        this.x -= this.width / 2;
        this.y -= this.height / 2;
        this.x = Number(this.x.toPrecision(2));
        this.y = Number(this.y.toPrecision(2));
    }

    update(game){
        this.changeVelocity(game);
        if(this.vx != 0){
            this.rotation = -Math.sign(this.vx);
        }
        this.collide(game);
        this.animate();
    }

    changeVelocity(game){
        this.velocity = this.speed;
        this.vx = 0;
        this.vy = 0;
        if(game.keysPressed["w"]){
            this.vy += this.velocity;
        }
        if(game.keysPressed["a"]){
            this.vx += this.velocity;
        }
        if(game.keysPressed["s"]){
            this.vy -= this.velocity;
        }
        if(game.keysPressed["d"]){
            this.vx -= this.velocity;
        }
        if(this.vx && this.vy){
            this.velocity = Math.round(Math.sqrt(this.velocity * this.velocity / 2)*10)/10;
            this.vx = Math.sign(this.vx) * this.velocity;
            this.vy = Math.sign(this.vy) * this.velocity;
        }
    }

    collide(game){
        let vx = this.vx;
        let vy = this.vy;
        for(let i = 0; i < game.interactable.length; i++){
            if(game.interactable[i] != this){
                [vx,vy] = checkCollision(game.interactable[i],this);
                if(vx == 0){
                    this.vx = 0;
                }
                if(vy == 0){
                    this.vy = 0;
                }
            }
        }
    }
}

class Enemy extends VisibleObject{
    constructor(x,y,width,height){
        super(x,y,width,height);
        this.image = document.getElementById("knight_walking");
        this.spriteWidth = 32;
        this.spriteHeight = 32;
        this.speed = 1;
        this.vx = 0;
        this.vy = 0;
    }

    update(game){
        super.update(game);
        this.vx = 0;
        this.vy = 0;
        if(game.player.x > this.x){
            this.vx += this.speed;
        }
        else{
            this.vx -= this.speed;
        }
        if(game.player.y > this.y){
            this.vy += this.speed;
        }
        else{
            this.vy -= this.speed;
        }
        this.x += this.vx;
        this.y += this.vy;
        if(this.vx != 0){
            this.rotation = Math.sign(this.vx);
        }
        this.animate();
    }
}

class Sword extends GameObject{
    constructor(x,y,width,height,parent){
        super(x,y,width,height);
        this.image = document.getElementById("sword_idle");
        this.spriteWidth = 50;
        this.spriteHeight = 10;
        this.parent = parent;
        this.damage = 10;
        this.angle = 40;
    }

    update(game){
        this.rotation = this.parent.rotation;
        if(this.rotation == -1){
            this.angle = 40;
            this.x = this.parent.x - this.width + Math.round(this.angle/2.22);
            this.y = this.parent.y + this.parent.height - this.height - 18;
        }
        else{
            this.angle = -40;
            this.x = this.parent.x + this.parent.width - Math.round(Math.abs(this.angle/2.22));
            this.y = this.parent.y + this.parent.height - this.height - 18;
        }
    }
}

class Arena{
    constructor(x1,y1,width,height){
        let thickness = 50;
        let x2 = x1 + width;
        let y2 = y1 + height - thickness;
        this.acrossTop = new VisibleObject(x1,y1,width,thickness);
        this.acrossBottom = new VisibleObject(x1,y2,width,thickness);
        this.downLeft = new VisibleObject(x1,y1+thickness,thickness,height-thickness);
        this.downRight = new VisibleObject(x2-thickness,y1+thickness,thickness,height-thickness);
        this.toUpdate = [this.acrossTop,this.acrossBottom,this.downLeft,this.downRight];
        this.toDraw = [this.acrossTop,this.acrossBottom,this.downLeft,this.downRight];
    }
}

class Game{
    constructor(){
        [this.canvas, this.ctx] = getCanvasContext();
        this.keysPressed = {
            "w" : false,
            "a" : false,
            "s" : false,
            "d" : false
        };
        let centre = {x:this.canvas.width/2,y:this.canvas.height/2};
        let arenaWidth = this.canvas.width * 1.5;
        let arenaHeight = this.canvas.height * 1.5;
        this.arena = new Arena(centre.x - arenaWidth/2,centre.y - arenaHeight/2,arenaWidth,arenaHeight);
        this.player = new Player(centre.x,centre.y,64,64);
        this.enemy = new Enemy(100,100,64,64);
        this.toUpdate = [this.player.toUpdate,this.arena.toUpdate,this.enemy].flat();
        this.toDraw = [this.player.toDraw,this.arena.toDraw,this.enemy].flat();
        this.interactable = [this.arena.toUpdate].flat();
    }

    start(){
        this.player.start();
        document.addEventListener("keydown",function(e){game.keysPressed = handleKeyDown(e,game.keysPressed)});
        document.addEventListener("keyup",function(e){game.keysPressed = handleKeyUp(e,game.keysPressed)});
        this.loop();
    }

    update(){
        for(let i = 0; i < this.toUpdate.length; i++){
            this.toUpdate[i].update(this);
        }
    }

    draw(){
        this.ctx.clearRect(0,0,this.canvas.width,this.canvas.height);
        for(let i = 0; i < this.toDraw.length; i++){
            this.toDraw[i].draw(this.ctx);
        }
    }

    loop(){
        this.update();
        this.draw();
        requestAnimationFrame(this.loop.bind(this));
    }
}


var game = new Game();
game.start();